package hotelbookingpage;



import static org.junit.Assert.assertEquals;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import bean.HotelBookingPageBean;
import cucumber.api.java.After;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class StepDef {
	private WebDriver driver;
	private HotelBookingPageBean hotelBookingPageBean;

	@Before
	public void setUp() {
		System.setProperty("webdriver.chrome.driver",
				"D:\\Users\\shamonda\\Desktop\\Selenium\\chromedriver.exe");
		driver=new ChromeDriver();
		hotelBookingPageBean=new HotelBookingPageBean(driver);
	}

	@Given("^open Hotel Booking page$")
	public void open_Hotel_Booking_page() throws Throwable {
		driver.get("http://localhost:8081/HotelBookings/pages/hotelbooking.html");
		assertEquals("Hotel Booking Form",hotelBookingPageBean.getPageHeading());
	}

	@Given("^Personel and payment details$")
	public void personel_and_payment_details() throws Throwable {
		hotelBookingPageBean.setFirstName("Shatabdee");
		hotelBookingPageBean.setLastName("Mondal");
		hotelBookingPageBean.setEmail("shatabdee.mondal@gmail.com");
		hotelBookingPageBean.setPhone("8897109898");
		hotelBookingPageBean.setAddress("Peeranchervu");
		hotelBookingPageBean.setCity("Hyderabad");
		hotelBookingPageBean.setState("Telangana");
		hotelBookingPageBean.setNumberOfGuestsstaying("5");
		hotelBookingPageBean.setCardHolderName("Shatabdee");
		hotelBookingPageBean.setDebitCardNumber("8956325632587421");
		hotelBookingPageBean.setCvv("143");
		hotelBookingPageBean.setExpireMonth("09");
		hotelBookingPageBean.setExpireYear("2025");
		Thread.sleep(1000);
	}

	@When("^Personel And payment details are not empty$")
	public void personel_And_payment_details_are_not_empty() throws Throwable {
		hotelBookingPageBean.onSubmit_navigate_to_successPage();
		Thread.sleep(1000);
	}

	@Then("^navigate to success page$")
	public void navigate_to_success_page() throws Throwable {
		driver.navigate().to("http://localhost:8081/HotelBookings/pages/success.html");
	}

	@Given("^Personel and payment details are null$")
	public void personel_and_payment_details_are_null() throws Throwable {
		driver.findElement(By.name("txtFN")).sendKeys("");
	}

	@When("^Personel And payment details are empty$")
	public void personel_And_payment_details_are_empty() throws Throwable {
		hotelBookingPageBean.onSubmit_navigate_to_successPage();
		Thread.sleep(1000);
	}

	@Then("^show alert messages$")
	public void show_alert_messages() throws Throwable {
		String msg = driver.switchTo().alert().getText();
		assertEquals("Please fill the First Name",msg);
	}
	@After
	public void tearDown() {
		driver.quit();
	}
} 

