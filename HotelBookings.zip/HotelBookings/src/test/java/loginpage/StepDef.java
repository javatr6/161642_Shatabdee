package loginpage;


import static org.junit.Assert.assertEquals;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import bean.HotelBookingPageBean;
import bean.LoginBean;
import bean.SuccessBean;
import cucumber.api.java.After;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class StepDef {
	private WebDriver driver;
	private HotelBookingPageBean hotelBookingPageBean;
	private LoginBean loginBean;
	@Before
	public void setUp() {
		System.setProperty("webdriver.chrome.driver",
				"D:\\Users\\shamonda\\Desktop\\Selenium\\chromedriver.exe");
		driver=new ChromeDriver();
		hotelBookingPageBean=new HotelBookingPageBean(driver);
		loginBean=new LoginBean(driver);
	}

	@Given("^open login page$")
	public void open_login_page() throws Throwable {
		driver.get("http://localhost:8081/HotelBookings/login.html");

		assertEquals("Hotel Booking Application",loginBean.getPageHeading());
	}

	@Given("^username and password$")
	public void username_and_password() throws Throwable {
		loginBean.assignValues("Capgemini", "capg1234");
	}

	@When("^login validate details$")
	public void login_validate_details() throws Throwable {
		loginBean.setSignBtn();
	}

	@Then("^redirect to hotelbooking page$")
	public void redirect_to_hotelbooking_page() throws Throwable {
		driver.navigate().to("http://localhost:8081/HotelBookings/pages/hotelbooking.html");
		assertEquals("Hotel Booking Form",hotelBookingPageBean.getPageHeading());
	}

	@Given("^username$")
	public void username() throws Throwable {
		loginBean.assignValues("", "capg1234");
	}

	@When("^login is performed$")
	public void login_is_performed() throws Throwable {
		loginBean.setSignBtn();
	}

	@Then("^show invalid username$")
	public void show_invalid_username() throws Throwable {
		String userErrorMsg=driver.findElement(By.xpath("//*[@id=\"userErrMsg\"]")).getText();
		System.out.println("Msg"+userErrorMsg);
		assertEquals("* Please enter userName.",userErrorMsg);
		Thread.sleep(1000);
	}

	@Given("^password$")
	public void password() throws Throwable {
		loginBean.assignValues("Capgemini", "");
	}

	@When("^login$")
	public void login() throws Throwable {
		loginBean.setSignBtn();
	}

	@Then("^show invalid password$")
	public void show_invalid_password() throws Throwable {
		String userErrorMsg=driver.findElement(By.xpath("//*[@id=\"pwdErrMsg\"]")).getText();
		System.out.println("Msg"+userErrorMsg);
		assertEquals("* Please enter password.",userErrorMsg);
	}
	@After
	public void tearDown() {
		driver.quit();
	}
}
