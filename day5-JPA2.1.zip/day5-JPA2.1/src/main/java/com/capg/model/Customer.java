package com.capg.model;



import java.time.LocalDate;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
@Entity
public class Customer {
	@Id
	@GeneratedValue
	private int custId;
	private String firstName;
	private String lastName;
	private Double regFee;
	private LocalDate pDate;
	public Customer() {
		super();
	}
	
	public Customer(String firstName, String lastName, Double regFee, LocalDate pDate) {
		super();
		this.firstName = firstName;
		this.lastName = lastName;
		this.regFee = regFee;
		this.pDate = pDate;
	}

	public Customer(int custId, String firstName, String lastName, Double regFee, LocalDate pDate) {
		super();
		this.custId = custId;
		this.firstName = firstName;
		this.lastName = lastName;
		this.regFee = regFee;
		this.pDate = pDate;
	}

	public LocalDate getpDate() {
		return pDate;
	}

	public void setpDate(LocalDate pDate) {
		this.pDate = pDate;
	}

	public Customer(String firstName, String lastName, Double regFee) {
		super();
		this.firstName = firstName;
		this.lastName = lastName;
		this.regFee = regFee;
	}
	public Customer(int custId, String firstName, String lastName, Double regFee) {
		super();
		this.custId = custId;
		this.firstName = firstName;
		this.lastName = lastName;
		this.regFee = regFee;
	}
	
	
	public int getCustId() {
		return custId;
	}
	public void setCustId(int custId) {
		this.custId = custId;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public Double getRegFee() {
		return regFee;
	}
	public void setRegFee(Double regFee) {
		this.regFee = regFee;
	}

	@Override
	public String toString() {
		return "Customer [custId=" + custId + ", firstName=" + firstName + ", lastName=" + lastName + ", regFee="
				+ regFee + ", pDate=" + pDate + "]";
	}
	

}
