package com.capg.onetomany;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.OneToMany;
@Entity
public class Company {
	
	@Id
	@GeneratedValue
	private int companyId;
	private String companyName;
	
	@OneToMany(mappedBy="company",targetEntity=Employee.class,cascade=CascadeType.ALL,fetch=FetchType.LAZY)
	private List<Employee> empList=new ArrayList<>();


	public Company() {
		super();
	}


	public Company(String companyName) {
		super();
		this.companyName = companyName;
	}


	public Company(String companyName, List<Employee> empList) {
		super();
		this.companyName = companyName;
		this.empList = empList;
	}


	public Company(int companyId, String companyName, List<Employee> empList) {
		super();
		this.companyId = companyId;
		this.companyName = companyName;
		this.empList = empList;
	}


	public int getCompanyId() {
		return companyId;
	}


	public void setCompanyId(int companyId) {
		this.companyId = companyId;
	}


	public String getCompanyName() {
		return companyName;
	}


	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}


	public List<Employee> getEmpList() {
		return empList;
	}


	public void setEmpList(List<Employee> empList) {
		this.empList = empList;
	}


	@Override
	public String toString() {
		return "Company [companyId=" + companyId + ", companyName=" + companyName + ", empList=" + empList + "]";
	}
	
	
	
	

}
