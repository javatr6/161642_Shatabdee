package com.capg.onetomany;

import java.time.LocalDate;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

public class Tester {
	public static void main(String args[]) {
		EntityManagerFactory emf=Persistence.createEntityManagerFactory("jpademo");
		EntityManager entityManager=emf.createEntityManager();
		EntityTransaction transaction=entityManager.getTransaction();
		
		transaction.begin();
		
		
		Company company1=new Company("TCS");
		Company company2=new Company("Wipro");
		Company company3=new Company("Infosys");
		
		Employee employee1=new Employee(1001,"shatabdee",LocalDate.now(),company1);
		Employee employee2=new Employee(1002,"gargi",LocalDate.of(2017,9,21),company2);
		Employee employee3=new Employee(1003,"mahuya",LocalDate.of(2015,3,11),company3);
		Employee employee4=new Employee(1004,"mahuya",LocalDate.of(2016,2,01),company3);
	
		entityManager.persist(company1);
		entityManager.persist(company2);
		entityManager.persist(company3);
		 
		entityManager.persist(employee1);
		entityManager.persist(employee2);
		entityManager.persist(employee3);
		entityManager.persist(employee4);
		
		transaction.commit();
		entityManager.close();
	}

}
