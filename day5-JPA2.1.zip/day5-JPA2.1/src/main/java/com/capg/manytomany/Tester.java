package com.capg.manytomany;

import java.time.LocalDate;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

import com.capg.model.Address;
import com.capg.model.Customer;

public class Tester {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		EntityManagerFactory emf=Persistence.createEntityManagerFactory("jpademo");
		EntityManager entityManager=emf.createEntityManager();
		EntityTransaction transaction=entityManager.getTransaction();
		
		transaction.begin();
		
		Events servlets=new Events("123-servlets","servlets",LocalDate.of(2018, 9, 21));
		Events python=new Events("456-python","python",LocalDate.of(2014, 6, 17));
		Events iot=new Events("789-iot","iot",LocalDate.of(2012,4, 23));
		
		Delegates delegates1=new Delegates(1,"Shatabdee");
		Delegates delegates2=new Delegates(2,"ram");
		Delegates delegates3=new Delegates(3,"krish");
		Delegates delegates4=new Delegates(51,"seetha");
		Delegates delegates5=new Delegates(16,"john");
		Delegates delegates6=new Delegates(71,"tom");
		
		delegates1.getEvents().add(servlets);
		delegates1.getEvents().add(iot);
		delegates2.getEvents().add(python);
		delegates3.getEvents().add(iot);
		delegates3.getEvents().add(servlets);
		delegates4.getEvents().add(python);
		delegates5.getEvents().add(iot);
		delegates6.getEvents().add(servlets);
		delegates5.getEvents().add(python);
		
		entityManager.persist(delegates1);
		entityManager.persist(delegates2);
		entityManager.persist(delegates3);
		entityManager.persist(delegates4);
		entityManager.persist(delegates5);
		entityManager.persist(delegates6);
		entityManager.persist(servlets);
		entityManager.persist(python);
		entityManager.persist(iot);
		
		transaction.commit();
		entityManager.close();

	}

}
