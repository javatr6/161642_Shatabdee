package org.cap.dao;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import javax.persistence.Query;

import org.cap.model.LoginBean;
import org.cap.model.PassRequestForm;
import org.cap.model.Routetable;
import org.cap.model.TransactionBean;

public class LoginJPA implements ILoginDAO {
	EntityManagerFactory emf = 
			Persistence.createEntityManagerFactory("test");
	EntityManager em = emf.createEntityManager();
	EntityTransaction transaction= em.getTransaction();
	@Override
	public boolean checkUser(LoginBean loginBean) {
		String str="from LoginBean where username=? and password=? ";
		Query query =em.createQuery(str);
		query.setParameter(1, loginBean.getUsername());
		query.setParameter(2, loginBean.getPassword());
		List<LoginBean> beans=query.getResultList();
		Iterator<LoginBean> iterator=beans.iterator();
		if(iterator.hasNext()) {
			return true;
		}
		return false;
	}

	@Override
	public PassRequestForm createRequest(PassRequestForm passRequestBean) {
		//	String sql="insert into BusPassRequest(EmployeeId,firstname,lastname,gender,address,email,dateofjoin,location,pickuploc,pickuptime,status,designation)values(?,?,?,?,?,?,?,?,?,?,?,?)";
		transaction.begin();

		em.persist(passRequestBean);

		transaction.commit();
		em.close();
		return passRequestBean;
	}

	@Override
	public List<Routetable> listAllRoutes() {
		String sql="from Routetable";
		Query query =em.createQuery(sql);
		List<Routetable> beans=query.getResultList();
		return beans;
	}

	@Override
	public Routetable addRoute(Routetable newroute) {
		transaction.begin();

		em.persist(newroute);

		transaction.commit();
		em.close();
		return newroute;
	}

	@Override
	public List<String> PendingReqServlet() {
		String sql="from PassRequestForm where status='pending'";
		Query query =em.createQuery(sql);
		List<PassRequestForm> beans=query.getResultList();
		List<String> idList=new ArrayList();
		Iterator<PassRequestForm> iterator=beans.iterator();
		while(iterator.hasNext()) {
			PassRequestForm passRequestForm=iterator.next();
			idList.add(passRequestForm.getEmployeeid());
		}
		return idList;
	}

	@Override
	public List<PassRequestForm> pendingDetails() {
		String sql="from PassRequestForm where status='pending'";
		Query query =em.createQuery(sql);
		List<PassRequestForm> beans=query.getResultList();
		Iterator<PassRequestForm> iterator=beans.iterator();
		if(iterator.hasNext()) {
			return beans;
		}
		return null;
	}

	@Override
	public List<PassRequestForm> pendingDetailsOfEmp(String empid) {
		String sql="from PassRequestForm where employeeid=?";
		Query query =em.createQuery(sql);
		query.setParameter(1, empid);
		List<PassRequestForm> beans=query.getResultList();
		Iterator<PassRequestForm> iterator=beans.iterator();
		if(iterator.hasNext()) {
			return beans;
		}
		return null;
	}

	@Override
	public Integer transaction(TransactionBean transaction) {
		// TODO Auto-generated method stub
		return null;
	}

}
