package com.capg.model;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

public class Tester {
	public static void main(String srgs[]) {
		EntityManagerFactory emf=Persistence.createEntityManagerFactory("jpademo");
		EntityManager entityManager=emf.createEntityManager();
		EntityTransaction transaction=entityManager.getTransaction();
		
		transaction.begin();
		
		Customer cust1=new Customer("Shatabdee","Mondal",20000.00);
		Address address1=new Address(1001,"Hyd",cust1);
		
		Customer cust2=new Customer("Gargi","Mondal",10000.00);
		Address address2=new Address(1002,"Delhi",cust2);
		
		entityManager.persist(cust1);
		entityManager.persist(address1);
		
		
		entityManager.persist(cust2);
		entityManager.persist(address2);
		
		transaction.commit();
		entityManager.close();
		
	}

}
